<script>
export default {
  name: 'App',
  data() {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>

<template>
<h3>模板语法</h3>
<p>{{ msg }}</p>
</template>

